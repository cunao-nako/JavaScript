window.addEventListener('DOMContentLoaded', () => {
  // Navigation Items
  const navItems = document.querySelectorAll('.nav-link');
  let currentPage = document.querySelector('.is-active'),
      activeItem;

  console.log(navItems);
  console.log(currentPage);
  navItems.forEach(item => {
    item.addEventListener('click', () => {
      console.log(currentPage);
      currentPage.classList.toggle('is-active');
      item.classList.toggle('is-active');
      currentPage = item;
    });
  });

  // Buttons
  const buttons = document.querySelectorAll('.btn');

  buttons.forEach(button => {
    button.addEventListener('mouseenter', (event) => {
      event.target.classList.toggle('btn-mouseenter');
    });
    button.addEventListener('mouseout', (event) => {
      event.target.classList.toggle('btn-mouseenter');
    });
  });
});
